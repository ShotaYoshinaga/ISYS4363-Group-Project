﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace user_interface
{
    public partial class FavoriteCarList : Form
    {
        public FavoriteCarList()
        {
            InitializeComponent();
        }

        public List<CommonValue> Values { get; set; }

        public void AddToGrid(List<CommonValue> val) 
            {

            }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnHomeRev_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerMenu f2 = new CustomerMenu();
            f2.Show();
        }
    }
    
   
    }

