﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class Reservation : Form
    {
        public Reservation()
        {
            InitializeComponent();
        }

        private void btnHome2_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerMenu f2 = new CustomerMenu();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$";
            string Query = "insert into PROJECTF2106.dbo.Reservation (Name,Inputdate,Phone,Email,Budget,Information) Values('" + this.TxtRName.Text + "'," +
             "'" + this.TxtRDate.Text + "','" + this.TxtRPhone.Text + "','" + this.TxtREm.Text + "','" + this.TxtRBud.Text + "','" + this.TxtRInfo.Text + "') ;";

            SqlConnection condatabase = new SqlConnection(constring);
            SqlCommand cdmdataBase = new SqlCommand(Query, condatabase);
            SqlDataReader myReader;
            try
            {
                condatabase.Open();
                myReader = cdmdataBase.ExecuteReader();
                MessageBox.Show("Reservation Submitted");
                while (myReader.Read())
                {


                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TxtRBud.Text = "";
            TxtRDate.Text = "";
            TxtREm.Text = "";
            TxtRInfo.Text = "";
            TxtRName.Text = "";
            TxtRPhone.Text = "";
            

        }
    }
}
