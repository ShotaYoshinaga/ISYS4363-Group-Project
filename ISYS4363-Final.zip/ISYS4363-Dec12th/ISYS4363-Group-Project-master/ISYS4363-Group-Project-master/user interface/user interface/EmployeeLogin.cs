﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class EmployeeLogin : Form
    {
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        private void EmployeeLogin_Load(object sender, EventArgs e)
        {

        }



        private void BtnEmplo_Click(object sender, EventArgs e)
        {
            SqlConnection Sqlcon = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$");
            String query = "Select * from LoginInfo Where username = '" + txtEmpUse.Text.Trim() + "' and password = '" + TxtEmpPass.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if(dtbl.Rows.Count == 1)
            {

                CarSelection objfrmMain = new CarSelection();
                this.Hide();
                objfrmMain.Show();

            }
            else

            {

                MessageBox.Show("Invalid Username or Password");

            }
            
            
            
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            EmploReg f2 = new EmploReg();
            f2.Show();
        }
    }
}
