﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace user_interface
{
    public class CommonValue
    {
        public string Year { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Type { get; set; }
        public string Edition { get; set; }
        public string Mileage { get; set; }
        public string Cost { get; set; }
        public string Color { get; set; }
        public string MonthlyPayment { get; set; }


    }
}
