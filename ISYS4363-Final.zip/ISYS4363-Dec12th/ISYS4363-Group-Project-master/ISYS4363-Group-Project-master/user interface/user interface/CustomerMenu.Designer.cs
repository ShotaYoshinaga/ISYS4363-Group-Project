﻿
namespace user_interface
{
    partial class CustomerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnReservation = new System.Windows.Forms.Button();
            this.btnUsedVehicle = new System.Windows.Forms.Button();
            this.btnReview = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnNewVehicle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(257, 396);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(323, 51);
            this.button1.TabIndex = 15;
            this.button1.Text = "Logout";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnReservation
            // 
            this.btnReservation.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnReservation.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReservation.Location = new System.Drawing.Point(501, 194);
            this.btnReservation.Margin = new System.Windows.Forms.Padding(2);
            this.btnReservation.Name = "btnReservation";
            this.btnReservation.Size = new System.Drawing.Size(288, 179);
            this.btnReservation.TabIndex = 12;
            this.btnReservation.Text = "Reservation";
            this.btnReservation.UseVisualStyleBackColor = false;
            this.btnReservation.Click += new System.EventHandler(this.btnReservation_Click);
            // 
            // btnUsedVehicle
            // 
            this.btnUsedVehicle.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnUsedVehicle.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsedVehicle.Location = new System.Drawing.Point(10, 194);
            this.btnUsedVehicle.Margin = new System.Windows.Forms.Padding(2);
            this.btnUsedVehicle.Name = "btnUsedVehicle";
            this.btnUsedVehicle.Size = new System.Drawing.Size(325, 179);
            this.btnUsedVehicle.TabIndex = 11;
            this.btnUsedVehicle.Text = "Used Vehicle";
            this.btnUsedVehicle.UseVisualStyleBackColor = false;
            this.btnUsedVehicle.Click += new System.EventHandler(this.btnUsedVehicle_Click);
            // 
            // btnReview
            // 
            this.btnReview.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnReview.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReview.Location = new System.Drawing.Point(501, 11);
            this.btnReview.Margin = new System.Windows.Forms.Padding(2);
            this.btnReview.Name = "btnReview";
            this.btnReview.Size = new System.Drawing.Size(288, 179);
            this.btnReview.TabIndex = 10;
            this.btnReview.Text = "Review";
            this.btnReview.UseVisualStyleBackColor = false;
            this.btnReview.Click += new System.EventHandler(this.btnReview_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnProfile.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.Location = new System.Drawing.Point(339, 11);
            this.btnProfile.Margin = new System.Windows.Forms.Padding(2);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(158, 343);
            this.btnProfile.TabIndex = 9;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnNewVehicle
            // 
            this.btnNewVehicle.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnNewVehicle.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewVehicle.Location = new System.Drawing.Point(10, 11);
            this.btnNewVehicle.Margin = new System.Windows.Forms.Padding(2);
            this.btnNewVehicle.Name = "btnNewVehicle";
            this.btnNewVehicle.Size = new System.Drawing.Size(325, 179);
            this.btnNewVehicle.TabIndex = 8;
            this.btnNewVehicle.Text = "New Vehicle ";
            this.btnNewVehicle.UseVisualStyleBackColor = false;
            this.btnNewVehicle.Click += new System.EventHandler(this.btnNewVehicle_Click);
            // 
            // CustomerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnReservation);
            this.Controls.Add(this.btnUsedVehicle);
            this.Controls.Add(this.btnReview);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnNewVehicle);
            this.Name = "CustomerMenu";
            this.Text = "Customer Menu";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnReservation;
        private System.Windows.Forms.Button btnUsedVehicle;
        private System.Windows.Forms.Button btnReview;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnNewVehicle;
    }
}