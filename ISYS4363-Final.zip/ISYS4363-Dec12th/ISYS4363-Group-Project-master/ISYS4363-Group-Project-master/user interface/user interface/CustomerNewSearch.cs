﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace user_interface
{
    
    public partial class CustomerNewSearch : Form
    {
        public CustomerNewSearch()
        {
            InitializeComponent();
        }


        DataTable dt = new DataTable("NewCars");

        private void CustomerNewSearch_Load(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString))
                {
                    if (cn.State == ConnectionState.Closed)
                        cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter("select *from NewCar", cn))
                    {

                        da.Fill(dt);
                        dgvNew.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtCNMake_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                DataView dv = dt.DefaultView;
                dv.RowFilter = string.Format("Make like '%{0}%'", TxtCNMake.Text);
                dgvNew.DataSource = dv.ToTable();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                DataView dv = dt.DefaultView;
                dv.RowFilter = string.Format("Model like '%{0}%'", TxtCNMod.Text);
                dgvNew.DataSource = dv.ToTable();
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                DataView dv = dt.DefaultView;
                dv.RowFilter = "Convert(Year, 'System.String') like '%" + TxtCNYear.Text + "%'";
                dgvNew.DataSource = dv.ToTable();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerMenu f2 = new CustomerMenu();
            f2.Show();
        }
    }
    
    

       
    }

