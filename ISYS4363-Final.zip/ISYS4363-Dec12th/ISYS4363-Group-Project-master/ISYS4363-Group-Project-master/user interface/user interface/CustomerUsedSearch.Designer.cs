﻿
namespace user_interface
{
    partial class CustomerUsedSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DgvUsed = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TxtUsedYear = new System.Windows.Forms.TextBox();
            this.TxtUsedMod = new System.Windows.Forms.TextBox();
            this.TxtUseMake = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnHomeRev = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DgvUsed)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DgvUsed
            // 
            this.DgvUsed.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.DgvUsed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvUsed.Location = new System.Drawing.Point(18, 138);
            this.DgvUsed.Margin = new System.Windows.Forms.Padding(2);
            this.DgvUsed.Name = "DgvUsed";
            this.DgvUsed.RowHeadersWidth = 82;
            this.DgvUsed.RowTemplate.Height = 33;
            this.DgvUsed.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvUsed.Size = new System.Drawing.Size(955, 255);
            this.DgvUsed.TabIndex = 24;
            this.DgvUsed.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DgvUsed_MouseClick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(400, 19);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(240, 29);
            this.label7.TabIndex = 0;
            this.label7.Text = "Used Vehicle Search";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TxtUsedYear);
            this.groupBox1.Controls.Add(this.TxtUsedMod);
            this.groupBox1.Controls.Add(this.TxtUseMake);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(12, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(955, 72);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            // 
            // TxtUsedYear
            // 
            this.TxtUsedYear.Location = new System.Drawing.Point(6, 41);
            this.TxtUsedYear.Name = "TxtUsedYear";
            this.TxtUsedYear.Size = new System.Drawing.Size(149, 20);
            this.TxtUsedYear.TabIndex = 14;
            this.TxtUsedYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtUsedYear_KeyPress);
            // 
            // TxtUsedMod
            // 
            this.TxtUsedMod.Location = new System.Drawing.Point(694, 40);
            this.TxtUsedMod.Name = "TxtUsedMod";
            this.TxtUsedMod.Size = new System.Drawing.Size(149, 20);
            this.TxtUsedMod.TabIndex = 13;
            this.TxtUsedMod.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtUsedMod_KeyPress);
            // 
            // TxtUseMake
            // 
            this.TxtUseMake.Location = new System.Drawing.Point(370, 40);
            this.TxtUseMake.Name = "TxtUseMake";
            this.TxtUseMake.Size = new System.Drawing.Size(143, 20);
            this.TxtUseMake.TabIndex = 12;
            this.TxtUseMake.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtUseMake_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(367, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 21);
            this.label1.TabIndex = 5;
            this.label1.Text = "Make";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(691, 16);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 21);
            this.label8.TabIndex = 3;
            this.label8.Text = "Model";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(5, 16);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 21);
            this.label9.TabIndex = 2;
            this.label9.Text = "Year";
            // 
            // btnHomeRev
            // 
            this.btnHomeRev.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnHomeRev.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeRev.Location = new System.Drawing.Point(18, 397);
            this.btnHomeRev.Margin = new System.Windows.Forms.Padding(2);
            this.btnHomeRev.Name = "btnHomeRev";
            this.btnHomeRev.Size = new System.Drawing.Size(96, 36);
            this.btnHomeRev.TabIndex = 30;
            this.btnHomeRev.Text = "Home";
            this.btnHomeRev.UseVisualStyleBackColor = false;
            this.btnHomeRev.Click += new System.EventHandler(this.btnHomeRev_Click);
            // 
            // CustomerUsedSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(978, 444);
            this.ControlBox = false;
            this.Controls.Add(this.btnHomeRev);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.DgvUsed);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimizeBox = false;
            this.Name = "CustomerUsedSearch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Used Vehicle Search";
            this.Load += new System.EventHandler(this.CustomerUsedSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DgvUsed)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DgvUsed;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnHomeRev;
        private System.Windows.Forms.TextBox TxtUseMake;
        private System.Windows.Forms.TextBox TxtUsedMod;
        private System.Windows.Forms.TextBox TxtUsedYear;
    }
}