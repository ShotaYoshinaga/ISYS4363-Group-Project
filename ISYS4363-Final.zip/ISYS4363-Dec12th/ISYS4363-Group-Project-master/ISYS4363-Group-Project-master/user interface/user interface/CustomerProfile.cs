﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class CustomerProfile : Form
    {
        public CustomerProfile()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                string constring = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$";
                string Query = "insert into PROJECTF2106.dbo.Cprofile (Firstname,Lastname,Birthday,Phone,Address) Values('" + this.TxtFirst.Text + "'," +
                 "'" + this.TxtLast.Text + "','" + this.TxtBirth.Text + "','" + this.TxtPhone.Text + "','" + this.TxtAdress.Text + "') ;";

                SqlConnection condatabase = new SqlConnection(constring);
                SqlCommand cdmdataBase = new SqlCommand(Query, condatabase);
                SqlDataReader myReader;
                try
                {
                    condatabase.Open();
                    myReader = cdmdataBase.ExecuteReader();
                    MessageBox.Show("Uploaded");
                    while (myReader.Read())
                    {


                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }


            }











        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To be Implemented");
        }

        private void btnHomeRev_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerMenu f2 = new CustomerMenu();
            f2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void CustomerProfile_Load(object sender, EventArgs e)
        {

        }
    }
}
