﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class EmploReg : Form
    {
        public EmploReg()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$";
            string Query = "insert into PROJECTF2106.dbo.Logininfo (username,password) Values('" + this.TxtUUse.Text + "'," +
             "'" + this.TxtUPass.Text + "') ;";

            SqlConnection condatabase = new SqlConnection(constring);
            SqlCommand cdmdataBase = new SqlCommand(Query, condatabase);
            SqlDataReader myReader;

            TxtUPass.Text = "";
            TxtUUse.Text = "";
            try
            {
                condatabase.Open();
                myReader = cdmdataBase.ExecuteReader();
                MessageBox.Show("Employee Account Created");
                while (myReader.Read())
                {


                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin f2 = new EmployeeLogin();
            f2.Show();
        }
    }
}
