﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class EmplReview : Form
    {
        public EmplReview()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void EmplReview_Load(object sender, EventArgs e)
        {
            //SqlConnection connection = new SqlConnection();
            //connection.ConnectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$";

            //SqlCommand Command = new SqlCommand();
            //Command.Connection = connection;
            //Command.CommandText = " SELECT * FROM Review";

            //DataTable Review_data = new DataTable();

            //SqlDataAdapter adapter = new SqlDataAdapter(Command);

            //adapter.Fill(Review_data);

            //DgvEmploRev.DataSource = Review_data;
        }

        private void BtnHome2_Click(object sender, EventArgs e)
        {
            this.Hide();
            CarSelection f2 = new CarSelection();
            f2.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            BindGrid();
        }

        public void BindGrid()
        {
            SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$");
            SqlCommand com = new SqlCommand("Select * from Review", con);
            SqlDataAdapter d = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            d.Fill(dt);
            DgvEmploRev.DataSource = dt;
        }

        private void DgvEmploRev_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (MessageBox.Show("Are you sure to Delete?", "Delete Record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string Comments = DgvEmploRev.Rows[e.RowIndex].Cells["Comments"].FormattedValue.ToString();
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$");
                con.Open();
                SqlCommand com = new SqlCommand("Delete Review where Comments = '" + Comments + "'", con);
                com.ExecuteNonQuery();
                MessageBox.Show("Successfully Deleted");
                con.Close();
                BindGrid();
            }
        }
    }
}
