﻿
namespace user_interface
{
    partial class Profiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DvgEmpPro = new System.Windows.Forms.DataGridView();
            this.BtnHome = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DvgEmpPro)).BeginInit();
            this.SuspendLayout();
            // 
            // DvgEmpPro
            // 
            this.DvgEmpPro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DvgEmpPro.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DvgEmpPro.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.DvgEmpPro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DvgEmpPro.Location = new System.Drawing.Point(1, 125);
            this.DvgEmpPro.Name = "DvgEmpPro";
            this.DvgEmpPro.Size = new System.Drawing.Size(787, 313);
            this.DvgEmpPro.TabIndex = 0;
            this.DvgEmpPro.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DvgEmpPro_CellClick);
            // 
            // BtnHome
            // 
            this.BtnHome.BackColor = System.Drawing.Color.RoyalBlue;
            this.BtnHome.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHome.Location = new System.Drawing.Point(620, 84);
            this.BtnHome.Name = "BtnHome";
            this.BtnHome.Size = new System.Drawing.Size(168, 31);
            this.BtnHome.TabIndex = 1;
            this.BtnHome.Text = "Home";
            this.BtnHome.UseVisualStyleBackColor = false;
            this.BtnHome.Click += new System.EventHandler(this.BtnHome_Click);
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnC.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.Location = new System.Drawing.Point(12, 84);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(240, 35);
            this.btnC.TabIndex = 2;
            this.btnC.Text = "Load Customer Profiles";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(311, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 22);
            this.label3.TabIndex = 9;
            this.label3.Text = "Click to delete row";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(286, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(210, 29);
            this.label4.TabIndex = 8;
            this.label4.Text = "Customer Profiles";
            // 
            // Profiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.BtnHome);
            this.Controls.Add(this.DvgEmpPro);
            this.Name = "Profiles";
            this.Text = "v";
            this.Load += new System.EventHandler(this.Profiles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DvgEmpPro)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DvgEmpPro;
        private System.Windows.Forms.Button BtnHome;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}