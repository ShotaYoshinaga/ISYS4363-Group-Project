﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class EmployeeCarNeww : Form
    {
        public EmployeeCarNeww()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            CarSelection f2 = new CarSelection();
            f2.Show();
        }

      

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewUpload_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$";
            string Query = "insert into PROJECTF2106.dbo.NewCar (Year,Make,Model,Type,Edition,Price,Color,DealerAddress,DealerPhone) Values('" + this.TxtNYear.Text + "'," +
             "'" + this.TxtNMake.Text + "','" + this.TxtNModel.Text + "','" + this.TxtNType.Text + "','" + this.TxtNEdition.Text + "','" + this.TxtNPrice.Text +
             "','" + this.TxtNColor.Text + "','" + this.TxtNDealAd.Text + "','" + this.TxtNDealNum.Text + "') ;";

            SqlConnection condatabase = new SqlConnection(constring);
            SqlCommand cdmdataBase = new SqlCommand(Query, condatabase);
            SqlDataReader myReader;
            try
            {
              condatabase.Open();
                myReader = cdmdataBase.ExecuteReader();
                MessageBox.Show("Uploaded");
                while (myReader.Read())
                {


                }


            }catch(Exception ex)
           {
                MessageBox.Show(ex.Message);

            }


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            TxtNColor.Text = "";
            TxtNDealAd.Text = "";
            TxtNDealNum.Text = "";
            TxtNEdition.Text = "";
            TxtNMake.Text = "";
            TxtNModel.Text = "";
            TxtNPrice.Text = "";
            TxtNType.Text = "";
            TxtNYear.Text = "";
            

        }

        private void EmployeeCarNeww_Load(object sender, EventArgs e)
        {

        }
    }
}
