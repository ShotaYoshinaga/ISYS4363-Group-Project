﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            CarSelection f2 = new CarSelection();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$";
            string Query = "insert into PROJECTF2106.dbo.UsedCar (Year,Make,Model,Type,Edition,Mileage,Cost,Color,MonthlyPayment) Values('" + this.TxtUYear.Text + "'," +
             "'" + this.TxtUMake.Text + "','" + this.TxtUModel.Text + "','" + this.TxtUType.Text + "','" + this.TxtUEdition.Text + "','" + this.TxtUMileage.Text +
             "','" + this.TxtUCost.Text + "','" + this.TxtUColor.Text + "','" + this.TxtUMonthly.Text + "') ;";

            SqlConnection condatabase = new SqlConnection(constring);
            SqlCommand cdmdataBase = new SqlCommand(Query, condatabase);
            SqlDataReader myReader;
            try
            {
                condatabase.Open();
                myReader = cdmdataBase.ExecuteReader();
                MessageBox.Show("Uploaded");
                while (myReader.Read())
                {


                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            TxtUColor.Text = "";
            TxtUCost.Text = "";
            TxtUEdition.Text = "";
            TxtUMake.Text = "";
            TxtUMileage.Text = "";
            TxtUModel.Text = "";
            TxtUMonthly.Text = "";
            TxtUType.Text = "";
            TxtUYear.Text = "";

        }
    }
}
