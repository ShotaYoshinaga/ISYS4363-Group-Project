﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace user_interface
{
    public partial class CustomerMenu : Form
    {
        public CustomerMenu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnNewVehicle_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerNewSearch f2 = new CustomerNewSearch();
            f2.Show();
        }

        private void btnUsedVehicle_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerUsedSearch f2 = new CustomerUsedSearch();
            f2.Show();
        }

        private void btnReview_Click(object sender, EventArgs e)
        {
            this.Hide();
            CarReview f2 = new CarReview();
            f2.Show();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerProfile f2 = new CustomerProfile();
            f2.Show();
        }

        private void btnReservation_Click(object sender, EventArgs e)
        {
            this.Hide();
            Reservation f2 = new Reservation();
            f2.Show();
        }

        private void btnMyFavs_Click(object sender, EventArgs e)
        {
            this.Hide();
            FavoriteCarList f2 = new FavoriteCarList();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginMenu f2 = new LoginMenu();
            f2.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
