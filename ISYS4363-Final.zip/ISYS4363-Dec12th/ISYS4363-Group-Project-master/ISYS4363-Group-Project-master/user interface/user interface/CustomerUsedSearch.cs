﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace user_interface
{
    public partial class CustomerUsedSearch : Form
    {

        public CustomerUsedSearch()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To be Implemented");
        }

        private void btnAddToFavs_Click(object sender, EventArgs e)
        {
            





















            //List<CommonValue> Cv = new List<CommonValue>();
            //foreach (DataGridViewRow item in DgvUsed.Rows)
            //{
            //    if (Convert.ToBoolean(item.Cells[0].Value))
            //    {
            //        Cv.Add(new CommonValue
            //        {
            //            Year = item.Cells[1].Value.ToString(),
            //            Make = item.Cells[2].Value.ToString(),
            //            Model = item.Cells[3].Value.ToString(),
            //            Type = item.Cells[4].Value.ToString(),
            //            Edition = item.Cells[5].Value.ToString(),
            //            Mileage = item.Cells[6].Value.ToString(),
            //            Cost = item.Cells[7].Value.ToString(),
            //            Color = item.Cells[8].Value.ToString(),
            //            MonthlyPayment = item.Cells[9].Value.ToString(),
            //        });

            //    }
            //}
           
        }
    
        private void btnAddToReserve_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To be Implemented");
        }

        private void btnHomeRev_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerMenu f2 = new CustomerMenu();
            f2.Show();
        }

        DataTable dt = new DataTable("UsedCars");
        private void CustomerUsedSearch_Load(object sender, EventArgs e)
        {
            try {
                using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString))
                {
                    if (cn.State == ConnectionState.Closed)
                        cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter("select *from UsedCar", cn))
                    {
                       
                        da.Fill(dt);
                        DgvUsed.DataSource= dt;
                    }
                }
             }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

     

        private void TxtUseMake_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                DataView dv = dt.DefaultView;
                dv.RowFilter = string.Format("Make like '%{0}%'", TxtUseMake.Text);
                DgvUsed.DataSource = dv.ToTable();
            }
        }

        private void TxtUsedMod_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                DataView dv = dt.DefaultView;
                dv.RowFilter = string.Format("Model like '%{0}%'", TxtUsedMod.Text);
                DgvUsed.DataSource = dv.ToTable();
            }
        }

        private void TxtUsedYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                DataView dv = dt.DefaultView;
                dv.RowFilter = "Convert(Year, 'System.String') like '%" + TxtUsedYear.Text + "%'";
                DgvUsed.DataSource = dv.ToTable();
            }
        }

        private void DgvUsed_MouseClick(object sender, MouseEventArgs e)
        {
            //if ((bool)DgvUsed.SelectedRows[0].Cells[0].Value == false)
            //{

//DgvUsed.SelectedRows[0].Cells[0].Value = true;

           // }
            //
           // {
//DgvUsed.SelectedRows[0].Cells[0].Value = false;
//}
        }
    }
}
