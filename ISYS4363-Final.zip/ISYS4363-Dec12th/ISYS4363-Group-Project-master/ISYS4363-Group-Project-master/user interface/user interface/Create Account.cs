﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace user_interface
{
    public partial class Create_Account : Form
    {
        public Create_Account()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=essql1.walton.uark.edu;Initial Catalog=PROJECTF2106;User ID=PROJECTF2106;Password=YD00etc$";
            string Query = "insert into PROJECTF2106.dbo.CustomerLogin (Username,Password) Values('" + this.TxtCUse.Text + "'," +
             "'" + this.TxtCPass.Text + "') ;";

            SqlConnection condatabase = new SqlConnection(constring);
            SqlCommand cdmdataBase = new SqlCommand(Query, condatabase);
            SqlDataReader myReader;

           TxtCPass.Text = "";
           TxtCUse.Text = "";
            try
            {
                condatabase.Open();
                myReader = cdmdataBase.ExecuteReader();
                MessageBox.Show("Customer Account Created");
                while (myReader.Read())
                {


                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            this.Hide();
             LoginForm f2 = new LoginForm();
            f2.Show();
        }
    }
}
